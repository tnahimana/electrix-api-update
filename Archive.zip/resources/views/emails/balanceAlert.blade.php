@component('mail::message')
<img src="{{ asset('electrix-home.png') }}" alt="Electrix" style="background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHC-jlb8GgDkIJunYOhdZsVPgp3U82ws2bfg&usqp=CAU'); background-repeat: no-repeat;
  background-size: 100% 100%" >
<h1>Your FDI Account Balance is running Low, Please Recharge soon!</h1>
<p>Remaining Balance:</p>

@component('mail::panel')
<h4 style="text-align: center">{{ $balance }} Frw</h4> 
@endcomponent

<p>This emain was sent as a remainder to recharge your FDI account</p>
<img src="https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,f_auto,q_auto:eco,dpr_1/bss4zl64us7e70arbf59" alt="FDI" width="100%" height="150px">
@endcomponent
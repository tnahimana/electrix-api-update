<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electrix Ltd - Electrix Ltd</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAsVBMVEVHcExVW+6QkvJTWu4pNOslMesgLeoaKeosN+s3QewpNesqNes9RuwyPOwlMeo3Ru4uOesjL+o6Q+wsN+vlzuZ/j/U4QOskMOoxPOwuOesQKu2JYNT/e1QyPOtgS9//SDT/LBciMOv/Mh//MjEAN/X/FCT/io7/YE4BQfv/MDv/DyD/Aw/0Ql4bO/HwMlenV7s0Pus2QOv/RlD/LDn/EQBRV+0ASf2dRrfmWIEmMev/hYuiCRj8AAAAO3RSTlMAHQoto/3//8Ng0ZtAcutnh/+IrQQQofLsvP6IE32Sj8K0qYrT8A8nn9L8/FbvwENMVTvo2FF+7aSKTrjCDy0AAAD7SURBVHgBxNJFYsMwEAXQb5ox20rNYWYu3/9eZVAca523FA7hBjRNh5JhWkRMZDtoornk+figBSE1HIkoxh9fuKhpkQbZXZhA5ogUmbD+5UUESSoMJMSyDLIyAwJmjvw/2uUDCVBw1e6gWdcGDK56fSi4EZBV2aADBcsAaDgaQ0WkcCajaTLrzOHmn4RWP7AYLaer9Xqz5W9G/YvderVarvcVk3P4cEzqQXaS0/lzX2iqNJPz/UPFuQ6ZXKjlIGJ2oVAuxqNHZh7+O0KWPvUXfKlVJPg3f96a8YusW8jfzV6vBqYMIUmUI6ceWsXY50z0PlCyx5txROidVwEk1Re5UPVZ1gAAAABJRU5ErkJggg==" rel="shortcut icon">
    <link href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAsVBMVEVHcExVW+6QkvJTWu4pNOslMesgLeoaKeosN+s3QewpNesqNes9RuwyPOwlMeo3Ru4uOesjL+o6Q+wsN+vlzuZ/j/U4QOskMOoxPOwuOesQKu2JYNT/e1QyPOtgS9//SDT/LBciMOv/Mh//MjEAN/X/FCT/io7/YE4BQfv/MDv/DyD/Aw/0Ql4bO/HwMlenV7s0Pus2QOv/RlD/LDn/EQBRV+0ASf2dRrfmWIEmMev/hYuiCRj8AAAAO3RSTlMAHQoto/3//8Ng0ZtAcutnh/+IrQQQofLsvP6IE32Sj8K0qYrT8A8nn9L8/FbvwENMVTvo2FF+7aSKTrjCDy0AAAD7SURBVHgBxNJFYsMwEAXQb5ox20rNYWYu3/9eZVAca523FA7hBjRNh5JhWkRMZDtoornk+figBSE1HIkoxh9fuKhpkQbZXZhA5ogUmbD+5UUESSoMJMSyDLIyAwJmjvw/2uUDCVBw1e6gWdcGDK56fSi4EZBV2aADBcsAaDgaQ0WkcCajaTLrzOHmn4RWP7AYLaer9Xqz5W9G/YvderVarvcVk3P4cEzqQXaS0/lzX2iqNJPz/UPFuQ6ZXKjlIGJ2oVAuxqNHZh7+O0KWPvUXfKlVJPg3f96a8YusW8jfzV6vBqYMIUmUI6ceWsXY50z0PlCyx5txROidVwEk1Re5UPVZ1gAAAABJRU5ErkJggg==" rel="apple-touch-icon">
</head>
<body class="bg-gray-100 font-sans">

    <!-- Hero Section -->
    <header class="bg-cover bg-center h-screen flex items-center text-white" style="background-image: url('https://electricalproducts.cellpack.com/fileadmin/user_upload/bbcgroup.biz/site/eproducts/images/used/006-Uberuns/0061-Unternehmens-Profil_Bilder/0061-Header_01_Cellpack_Electrical_Unternehmensprofil.jpg');">
        <div class="container mx-auto text-center">
            <h1 class="text-4xl md:text-6xl font-bold mb-4">Electrix Ltd</h1>
            <p class="text-lg md:text-xl mb-8">Your Trusted Partner in Electrical Solutions</p>
            <a href="#services" class="bg-white text-blue-500 px-6 py-3 rounded-full font-bold uppercase tracking-wide hover:bg-blue-500 hover:text-white">Powering Your Future</a>
        </div>
    </header>

</body>
</html>

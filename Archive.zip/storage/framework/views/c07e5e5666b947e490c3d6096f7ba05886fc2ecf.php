<?php $__env->startComponent('mail::message'); ?>
<img src="<?php echo e(asset('electrix-home.png')); ?>" alt="Electrix" style="background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHC-jlb8GgDkIJunYOhdZsVPgp3U82ws2bfg&usqp=CAU'); background-repeat: no-repeat;
  background-size: 100% 100%" >
<h1>Your FDI Account Balance is running Low, Please Recharge soon!</h1>
<p>Remaining Balance:</p>

<?php $__env->startComponent('mail::panel'); ?>
<h4 style="text-align: center"><?php echo e($balance); ?> Frw</h4> 
<?php echo $__env->renderComponent(); ?>

<p>This emain was sent as a remainder to recharge your FDI account</p>
<img src="https://res.cloudinary.com/crunchbase-production/image/upload/c_lpad,f_auto,q_auto:eco,dpr_1/bss4zl64us7e70arbf59" alt="FDI" width="100%" height="150px">
<?php echo $__env->renderComponent(); ?><?php /**PATH /Users/nahimana/Documents/workspace/electrix-meter-api/resources/views/emails/balanceAlert.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\RegMeter;
use App\Models\MobileUser;
use App\Models\Transaction;
use Illuminate\Support\Str;
use App\Mail\FDIBalanceMail;
use Illuminate\Http\Request;
use App\Models\ElectrixMeter;
use InvalidArgumentException;
use App\Models\FdiTransaction;
use Illuminate\Support\Carbon;
use App\Models\InitiatePayment;
use App\Models\VendTransaction;
use App\Models\PhonePreferences;
use App\Models\NewApiTransaction;
use App\Models\PaymentTransaction;
use App\Models\TransactionReclaim;
use App\Models\TransactionOverride;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use SebastianBergmann\Environment\Runtime;
use Illuminate\Http\Client\RequestException;

class FDIController extends Controller
{
    public $increament;
    private $isNewBalance = false;
    private $wallet_balance;

    public function queryMeter(Request $request)
    {
        $attrs = $request->validate([
            'meterno' => 'required | min:11'
        ]);
        return response($this->queryMeterNewApi($attrs['meterno']), 200);
    }

    public function queryLastToken(Request $request)
    {
        $attrs = $request->validate([
            'meterno' => 'required | min:11'
        ]);
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url, [
            "limit" => 50,
            "verticalId" => 'airtime',
            "customerAccountNumber" => $attrs['meterno'],
            "fdate" => Carbon::now()->subDays(30)->format('Y-m-d'),
            "tdate" =>  now()->format('Y-m-d'),
        ]);
        return $response->json();
    }

    public function generateElectricityToken(Request $request)
    {
        $attrs = $request->validate([
            'meterNumber' => 'required | min:11',
            'units' => 'required'
        ]);

        $amount = floatval($attrs['units']) * 189;
        $meter = $this->validateElectrixMeter($attrs['meterNumber']);
        $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        if ($meter) {
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
            ])->post($url, [
                'CompanyName' => getenv('COMPANY_NAME'),
                'UserName' => getenv('USERNAME'),
                'PassWord' => getenv('PASSWORD'),
                'MeterID' => strVal($meter),
                'is_vend_by_unit' => "false",
                'Amount' => strVal($amount)
            ]);
            $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', 'electrix_electricity')->where('resolve_status', false)->orderBy('id', 'DESC')->first();
            $updateTrx = FdiTransaction::where('id', $trx->id)
                ->update([
                    'electrix_meter_number' => $attrs['meterNumber'],
                    'resolve_status' => 1,
                    'is_reg_status' => 1,
                ]);
            return response([
                'data' => [
                    'status' => true,
                    'msg' => $meter . ' # Token has been generated successfully!',
                    'response' => $response->json()[0],
                    'token' => $response->json()[0]['Token'],
                ]
            ], 200);
        } else {
            return response([
                'data' => [
                    'status' => false,
                    'msg' => $meter . ' # meterno not doesn\'t exist',
                    'token' => null,
                ]
            ], 200);
        }
    }

    public function generateElectricityTokenNew($meterNumber, $units)
    {
        $unit = $this->calculateAmount($meterNumber, $units);
        $amount = floatval($unit) * 189;
        $meter = $this->validateElectrixMeter($meterNumber);
        if($meterNumber == '58101058236'){
            $url = getenv('ELECTRIX_ENDPOINT_NEW') . 'VendingMeter';
        }else{
            $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        }
        if ($meter) {
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
            ])->post($url, [
                'CompanyName' => getenv('COMPANY_NAME'),
                'UserName' => getenv('USERNAME'),
                'PassWord' => getenv('PASSWORD'),
                'MeterID' => strVal($meter),
                'is_vend_by_unit' => "false",
                'Amount' => strVal($amount)
            ]);
            $data = [
                'status' => true,
                'msg' => $meter . ' # Token has been generated successfully!',
                'response' => $response->json()[0],
                'token' => $response->json()[0]['Token'],
            ];
            return $data;
        } else {
            $data = [
                'status' => false,
                'msg' => $meter . ' # meterno not doesn\'t exist',
                'token' => null,
            ];
            return $data;
        }
    }

    public function generateRegToken(Request $request)
    {
        $attrs = $request->validate([
            'meterno' => 'required | min:11',
            'electrixMeterno' => 'required | min:11',
            'amount' => 'required | numeric',
            'customer_msisdn' => 'required | min:12',
            'trxref' => 'required',
        ]);
        $this->balanceRequest($request);
        $trx = $this->valitateTrx('electricity', $attrs['meterno']);
        if (gettype($trx) == 'integer') {
            $data = [
                "status_code" => 0,
                "status_msg" => "Meter not found: meter number " . $attrs['meterno'] . " does not exist or is not connected.",
                "data" => [
                    "msisdn" => $attrs['customer_msisdn'],
                    "amount" => $attrs['amount']
                ]
            ];
            return response($data, 200);
        } else { 
            if ($this->checkTrxTime($attrs['electrixMeterno']) >= 30) {
                $requestTrx = $this->validateTokenUse($attrs['amount'], $attrs['meterno']);
                if ($requestTrx == 'null') {
                    if($this->unblockTrx($attrs['meterno'], $attrs['electrixMeterno']) == true){
                        $returnData = $this->executeTrx($trx['data']['trxId'], $attrs['meterno'], $attrs['amount'], $trx['data']['verticalId'], $trx['data']['deliveryMethods']['0']['id'], $this->removeFirstDigits($attrs['customer_msisdn'], 2));
                        // $returnData = "/v2/trx/3afb91e1-2c6e-4287-ba4b-8b7fcbea5245/status/";
                        // $returnData = "/v2/trx/a189cd68-c9ad-4e1c-9190-3fc88ff36bdd/status/";
                        return $returnData;
                        $this->storeVendTrx('electricity', $trx['data']['trxId']);
                        if (is_null($returnData)) {
                            $data = [
                                'status_code' => 0,
                                'status_msg' => 'Transction Barred for 3 minutes',
                                'data' => []
                            ];
                            return response([$data], 200);
                        } else {
                            sleep(2);
                            $trx = substr(substr($returnData, 3), 0, -1);
                            $trxData = $this->retrieveTrx($trx);
                            if ($trxData['data']['spVendInfo']['voucher'] != null && $trxData['data']['spVendInfo']['units'] != null) {
                                $meterId = ElectrixMeter::where('electrix_meter_number', $attrs['electrixMeterno'])->first()->id;
                                $this->storeNewApiData('electricity', $returnData, $trxData, $meterId);
                                $data = [
                                    "status_code" => 1,
                                    "status_msg" => "ELEC VEND METER:" . $trxData['data']['customerAccountNumber'] . " TOKEN:" . $trxData['data']['spVendInfo']['voucher'] . " UNITS: " . $trxData['data']['spVendInfo']['units'] . ", AMOUNT: " . $trxData['data']['spVendInfo']['trxAmount'] . " REF: .0000" . now() . " Name:" . $trxData['data']['customerAccountName'] . " RECEIVER:" . $attrs['customer_msisdn'] . ". Your balance is:" . $this->wallet_balance,
                                    "data" => [
                                        "units" => $trxData['data']['spVendInfo']['units'],
                                        "token" =>  $trxData['data']['spVendInfo']['voucher'],
                                        "meterno" => $trxData['data']['customerAccountNumber'],
                                        "regulatory_fees" => $trxData['data']['spVendInfo']['deductions'],
                                        "receipt_no" => $trxData['data']['spVendInfo']['receiptNo'],
                                        "amount" => $trxData['data']['spVendInfo']['trxAmount'],
                                        "vat" => $trxData['data']['spVendInfo']['vatNo'],
                                        "customer_name" => $trxData['data']['customerAccountName']
                                    ],
                                    "tstamp" => now()->format('Y-m-d H:i:s')
                                ];
                                if ($attrs['electrixMeterno'] == $attrs['meterno']) {
                                    return response($data, 200);
                                } else {
                                    if ($data) {
                                        $fdiStore = $this->fdiTransactionStore('electricity', json_encode($data), $attrs['customer_msisdn'], $attrs['electrixMeterno']);
                                        if ($fdiStore) {
                                            $token = $this->generateElectricityTokenNew($attrs['electrixMeterno'], $trxData['data']['spVendInfo']['units']);
                                            if ($token) {
                                                $userId = MobileUser::where('user_id', auth()->user()->id)->first()->id;
                                                $regId = RegMeter::where('reg_meter_number', $attrs['meterno'])->first()->id;
                                                $electrixId = ElectrixMeter::where('electrix_meter_number', $attrs['electrixMeterno'])->first()->id;
                                                $sale = $this->saleStore($userId, $regId, $electrixId, $trxData['data']['spVendInfo']['trxAmount'], $trxData['data']['spVendInfo']['trxAmount'], $this->formatNumberWithHyphens($trxData['data']['spVendInfo']['voucher']), $this->replaceSpacesWithHyphens($token['token']), $trxData['data']['spVendInfo']['units'], true);
                                                if ($sale) {
                                                    return response($data, 200);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }else{
                        return 'null';
                    }
                } else {
                    $trxData = json_decode(TransactionReclaim::where('token', $requestTrx)->first()->trx_data)->data;
                    $meterId = ElectrixMeter::where('electrix_meter_number', $attrs['electrixMeterno'])->first()->id;
                    $data = [
                        "status_code" => 1,
                        "status_msg" => "ELEC VEND METER:" . $trxData->customerAccountNumber . " TOKEN:" . $trxData->spVendInfo->voucher . " UNITS: " . $trxData->spVendInfo->units . ", AMOUNT: " . $trxData->spVendInfo->trxAmount . " REF: .0000" . now() . " Name:" . $trxData->customerAccountName . " RECEIVER:" . $attrs['customer_msisdn'] . ". Your balance is:" . $this->wallet_balance,
                        "data" => [
                            "units" => $trxData->spVendInfo->units,
                            "token" =>  $trxData->spVendInfo->voucher,
                            "meterno" => $trxData->customerAccountNumber,
                            "regulatory_fees" => $trxData->spVendInfo->deductions,
                            "receipt_no" => $trxData->spVendInfo->receiptNo,
                            "amount" => $trxData->spVendInfo->trxAmount,
                            "vat" => $trxData->spVendInfo->vatNo,
                            "customer_name" => $trxData->customerAccountName
                        ],
                        "tstamp" => now()->format('Y-m-d H:i:s')
                    ];
                    $token = $this->generateElectricityTokenNew($attrs['electrixMeterno'], $trxData->spVendInfo->units);
                    $updateTokenUse = TransactionReclaim::where('token', $requestTrx)->update([
                        'use_status' => true
                    ]);
                    if ($token) {
                        $userId = MobileUser::where('user_id', auth()->user()->id)->first()->id;
                        $regId = RegMeter::where('reg_meter_number', $attrs['meterno'])->first()->id;
                        $electrixId = ElectrixMeter::where('electrix_meter_number', $attrs['electrixMeterno'])->first()->id;
                        $sale = $this->saleStore($userId, $regId, $electrixId, $trxData->spVendInfo->trxAmount, $trxData->spVendInfo->trxAmount, $this->formatNumberWithHyphens($trxData->spVendInfo->voucher), $this->replaceSpacesWithHyphens($token['token']), $trxData->spVendInfo->units, true);
                        if ($sale) {
                            return response($data, 200);
                        }
                    }
                }
            } else {
                $trx = substr(substr($this->getTrxData($attrs['electrixMeterno']), 3), 0, -1);
                $trxData = $this->retrieveTrx($trx);
                if ($trxData['data']['spVendInfo']['voucher'] != null && $trxData['data']['spVendInfo']['units'] != null) {
                    $meterId = ElectrixMeter::where('electrix_meter_number', $attrs['electrixMeterno'])->first()->id;
                    $data = [
                        "status_code" => 1,
                        "status_msg" => "ELEC VEND METER:" . $trxData['data']['customerAccountNumber'] . " TOKEN:" . $trxData['data']['spVendInfo']['voucher'] . " UNITS: " . $trxData['data']['spVendInfo']['units'] . ", AMOUNT: " . $trxData['data']['spVendInfo']['trxAmount'] . " REF: .0000" . now() . " Name:" . $trxData['data']['customerAccountName'] . " RECEIVER:" . $attrs['customer_msisdn'] . ". Your balance is:" . $this->wallet_balance,
                        "data" => [
                            "units" => $trxData['data']['spVendInfo']['units'],
                            "token" =>  $trxData['data']['spVendInfo']['voucher'],
                            "meterno" => $trxData['data']['customerAccountNumber'],
                            "regulatory_fees" => $trxData['data']['spVendInfo']['deductions'],
                            "receipt_no" => $trxData['data']['spVendInfo']['receiptNo'],
                            "amount" => $trxData['data']['spVendInfo']['trxAmount'],
                            "vat" => $trxData['data']['spVendInfo']['vatNo'],
                            "customer_name" => $trxData['data']['customerAccountName']
                        ],
                        "tstamp" => now()->format('Y-m-d H:i:s')
                    ];
                    return response($data, 200);
                }
            }
        }
    }

    public function startimeSubscription(Request $request)
    {
        $attrs = $request->validate([
            'smartcard' => 'required | min:11',
            'customer_msisdn' => 'required | min:12',
            'amount' => 'required | numeric',
            'trxref' => 'required',
        ]);
        $this->balanceRequest($request);
        $trx = $this->valitateTrx('paytv', $attrs['smartcard']);
        if (gettype($trx) == 'integer') {
            $data = [
                "status_code" => 0,
                "status_msg" => $attrs['smartcard'] . " subscriber_not_found",
                "data" => [
                    "msisdn" => $attrs['customer_msisdn'],
                    "amount" => $attrs['amount']
                ]
            ];
            return response($data, 200);
        } else {
            if ($this->retrieveVendTrx('paytv') != null) {
                $returnData = $this->retrieveVendTrx('paytv')['trx_id'];
            } else {
                $returnData = $this->executeTrx($trx['data']['trxId'], $this->removeFirstDigits($attrs['customer_msisdn'], 2), $attrs['amount'], $trx['data']['verticalId'], $trx['data']['deliveryMethods']['0']['id'], $this->removeFirstDigits($attrs['customer_msisdn'], 2));
            }
            $this->storeVendTrx('paytv', $returnData);
            if (is_null($returnData)) {
                $data = [
                    'status_code' => 0,
                    'status_msg' => 'Transction Barred for 3 minutes',
                    'data' => []
                ];
                return response($data, 200);
            } else {
                $trx = substr(substr($returnData, 3), 0, -1);
                $trxData = $this->retrieveTrx($trx);
                $this->storeNewApiData('paytv', $returnData, $trxData);
                $data = [
                    "status_code" => 1,
                    "status_msg" => "Startimes subscription was successful. SMARTCARD: " . $attrs['smartcard'] . " AMOUNT: " . $attrs['amount'] . " RWF REF: " . $attrs['customer_msisdn'] . "_" . $attrs['smartcard'] . "_" . now()->format('YmdHis') . random_int(100000, 999999) . " CUSTOMER: " . $attrs['customer_msisdn'] . " Your balance is: " . $this->wallet_balance,
                    "data" => [
                        "msisdn" => $attrs['customer_msisdn'],
                        "smartcard" => $attrs['smartcard'],
                        "amount" => $attrs['amount'],
                        "trxref" => $trx['data']['trxId']
                    ],
                    "tstamp" => now()->format('Y-m-d H:i:s')
                ];
                $this->deleteVendTrx('paytv', $returnData);
                return response($data, 200);
            }
        }
    }

    public function airtimeTopup(Request $request)
    {
        $attrs = $request->validate([
            'customer_msisdn' => 'required | min:12',
            'amount' => 'required | numeric',
            'trxref' => 'required',
        ]);
        $this->balanceRequest($request);
        $trx = $this->valitateTrx('airtime', $attrs['customer_msisdn']);
        if (gettype($trx) == 'integer') {
            $data = [
                "status_code" => 0,
                "status_msg" => "Customer mobile number can only be a Rwanda SIMCard on either MTN, TIGO or Airtel networks",
                "data" => [
                    "msisdn" => $attrs['customer_msisdn'],
                    "amount" => $attrs['amount']
                ]
            ];
            return response($data, 200);
        } else {
            if ($this->retrieveVendTrx('airtime') != null) {
                $returnData = $this->retrieveVendTrx('airtime')['trx_id'];
            } else {
                $returnData = $this->executeTrx($trx['data']['trxId'], $this->removeFirstDigits($attrs['customer_msisdn'], 2), $attrs['amount'], $trx['data']['verticalId'], $trx['data']['deliveryMethods']['0']['id'], $this->removeFirstDigits($attrs['customer_msisdn'], 2));
            }
            $this->storeVendTrx('airtime', $returnData);
            if (is_null($returnData)) {
                $data = [
                    'status_code' => 0,
                    'status_msg' => 'Transction Barred for 3 minutes',
                    'data' => []
                ];
                return response($data, 200);
            } else {
                $trx = substr(substr($returnData, 3), 0, -1);
                $trxData = $this->retrieveTrx($trx);
                $this->storeNewApiData('airtime', $returnData, $trxData);
                $data = [
                    "status_code" => 1,
                    "status_msg" => "Trx successful. Phone: " . $attrs['customer_msisdn'] . ", Amt: " . floatval($attrs['amount']) . ", Commission: 4.2. Your combined wallet balance is: " . $this->wallet_balance,
                    "data" => [
                        "msisdn" => $attrs['customer_msisdn'],
                        "amount" => $attrs['amount']
                    ],
                    "tstamp" => now()->format('Y-m-d H:i:s')
                ];
                $this->deleteVendTrx('airtime', $returnData);
                return response($data, 200);
            }
        }
    }

    public function balanceRequest(Request $request)
    {
        $balance =  $this->balanceRequestNewAPI()['data']['wallet_balance'];
        $this->wallet_balance = $balance;
        return response($this->balanceRequestNewAPI(), 200);
    }

    public function validateElectrixMeter($meterNumber)
    {
        $meter = ElectrixMeter::where('electrix_meter_number', $meterNumber)->with('regmeter')->first();
        if ($meter != '') {
            return $meter->electrix_meter_number;
        } else {
            return null;
        }
    }

    public function fdiTransaction(Request $request)
    {
        $attrs = $request->validate([
            'transaction_type' => 'required',
            'transaction_data' => 'required',
            'customer_msisdn' => 'required',
        ]);

        $data = FdiTransaction::create([
            'user_id' => auth()->user()->id,
            'customer_msisdn' => $attrs['customer_msisdn'],
            'transaction_type' => $attrs['transaction_type'],
            'transaction_data' => $attrs['transaction_data'],
            'resolve_status' => 0,
        ]);
        if ($data) {
            return response([
                'data' => $data
            ], 200);
        }
    }

    public function fdiTransactionStore($transaction_type, $transaction_data, $customer_msisdn, $meterNumber)
    {
        $data = FdiTransaction::create([
            'user_id' => auth()->user()->id,
            'customer_msisdn' => $customer_msisdn,
            'transaction_type' => $transaction_type,
            'transaction_data' => $transaction_data,
            'resolve_status' => 0,
            'electrix_meter_number' => $meterNumber,
            'resolve_status' => 1,
            'is_reg_status' => 1,
        ]);
        if ($data) {
            return $data;
        }
    }

    public function retrieveFdiTrancactions()
    {
        return response([
            'fdi_transactions' => FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', '!=', 'electrix_electricity')->orderBy('id', 'DESC')->get()
        ], 200);
    }

    public function getFdiTrancactions($id)
    {
        $fdi = FdiTransaction::find($id);
        return response([
            'fdi_transactions' => [
                'id' => $fdi->id,
                'user_id' => $fdi->user_id,
                'customer_msisdn' => $fdi->customer_msisdn,
                'transaction_type' => $fdi->transaction_type,
                'transaction_data' => $fdi->transaction_data,
                'resolve_status' => $fdi->resolve_status,
                'created_at' => $fdi->created_at->format('D,d-M-Y  g:i A'),
            ]
        ], 200);
    }

    public function preferencesStore(Request $request)
    {
        $attrs = $request->validate([
            'user_id' => 'required',
            'phone' => 'required | digits:10 | unique:phone_preferences',
        ]);
        $phone_count = PhonePreferences::where('user_id', $attrs['user_id'])->get()->count();
        if ($phone_count >= 3) {
            $first_phone = PhonePreferences::where('user_id', $attrs['user_id'])->first();
            $first_phone->delete();
        }
        $preferences = PhonePreferences::create([
            'user_id' => $attrs['user_id'],
            'phone' => $attrs['phone'],
        ]);
        return response([
            'preferences' => $preferences
        ], 200);
    }

    public function getPreferences($user)
    {
        $preferences = PhonePreferences::where('user_id', $user)->orderBy('id', 'DESC')->get();
        return response([
            'preferences' => $preferences
        ], 200);
    }

    public function initiatePayment(Request $request)
    {
        $attrs = $request->validate([
            'txtRef' => 'required',
            'channelId' => 'required',
            'msisdn' => 'required',
            'amount' => 'required'
        ]);
        $token = $this->generateAuthToken();
        $url = getenv('FDI_PAYMENT') . "/" . "momo/pull";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer' . " " . $token
        ])->post($url, [
            "trxRef" => $attrs['txtRef'],
            "channelId" => $attrs['channelId'],
            "accountId" => getenv('FDI_AP_ID'),
            "msisdn" => $attrs['msisdn'],
            "amount" => $attrs['amount'],
            "callback" => "http://electrix-meter-api.test/api/payment-callback"
        ]);
        return $response->json();
    }

    public function generateAuthToken()
    {
        $url = getenv('FDI_PAYMENT') . "/" . "auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->post($url, [
            'appId' => getenv('FDI_AP_ID'),
            'secret' => getenv('FDI_AP_SECRET'),
        ]);
        return $response->json()['data']['token'];
    }

    public function availableChannels()
    {
        $token = $this->generateAuthToken();
        $url = getenv('FDI_PAYMENT') . "/" . "channels";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer' . " " . $token
        ])->get($url);
        return $response->json();
    }

    public function getTransactionInfo($txtRef)
    {
        $url = getenv('FDI_PAYMENT') . "/momo/trx/" . $txtRef . "/" . "info";
        $token = $this->generateAuthToken();
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer' . " " . $token
        ])->get($url);
        return $response->json();
    }

    public function storeTransactionInfo(Request $request)
    {
        $attrs = $request->validate([
            'payment_data' => 'required',
            'user_id' => 'required'
        ]);

        $transactions = PaymentTransaction::create([
            'user_id' => $attrs['user_id'],
            'payment_data' => $attrs['payment_data'],
        ]);

        return response([
            'transactions' => $transactions
        ], 200);
    }

    public function transactionInitiationStore(Request $request)
    {
        $attrs = $request->validate([
            'user_id' => 'required',
            'trxRef' => 'required | unique:initiate_payments'
        ]);
        $previous_trx = InitiatePayment::where('user_id', $attrs['user_id'])->get();
        $increament = $previous_trx->count();
        for ($i = 0; $i < $increament; $i++) {
            $previous_trx = json_decode($previous_trx)[$i]->trxRef;
            $trx_status = $this->getTransactionInfo($previous_trx);
            $status =  $trx_status['data']['trxStatus'];
            $trxRef = $trx_status['data']['trxRef'];
            if ($status == 'failed') {
                $trxDelete = InitiatePayment::where('trxRef', $trxRef)->first();
                $trxDelete->delete();
                $previous_trx = InitiatePayment::where('user_id', $attrs['user_id'])->get();
                $this->increament = $previous_trx;
            }
        }

        $trx = InitiatePayment::create([
            'user_id' => $attrs['user_id'],
            'trxRef' => $attrs['trxRef'],
        ]);
        $tenMinutesAgo = Carbon::now()->subMinutes(10);
        $trx =  InitiatePayment::where('user_id', $attrs['user_id'])->whereBetween('created_at', [$tenMinutesAgo, Carbon::now()])->get();
        return response([
            'transaction' => $trx
        ], 200);
    }

    public function transactionInitiationDelete($user_id, $trxRef)
    {
        $trx = InitiatePayment::where('user_id', $user_id)->where('trxRef', $trxRef)->delete();
        return response([
            'transaction' => $trx
        ], 200);
    }

    public function initiatedTrxRef($user_id)
    {
        $trx = InitiatePayment::where('user_id', $user_id)->get();
        return response([
            'transactions' => $trx
        ], 200);
    }

    public function getFdiTrx(Request $request)
    {
        $attrs = $request->validate([
            'trx_type' => 'required'
        ]);
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', $attrs['trx_type'])->where('resolve_status', false)->orderBy('id', 'DESC')->first();
        return response([
            'trx' => $trx
        ], 200);
    }

    public function failedPurchase($phone, $meter)
    {
        $trx_type = "electrix_electricity";
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', $trx_type)->where('resolve_status', false)->where('electrix_meter_number', "null")->orderBy('id', 'DESC')->first();
        if (empty($trx)) {
            return response([
                'trx' => null
            ], 200);
        } else {
            $electrixMeter = $meter;
            $trx_id = $trx['id'];
            $trx = $trx['transaction_data'];
            if (explode(',', explode(':', $trx)[1])[0] == 0) {
                return response([
                    'trx' => null
                ], 200);
            } elseif (explode(',', explode(':', $trx)[1])[0] == 1) {
                $trx = explode('":"', $trx);
                $trx = explode(' ', $trx[1]);
                $regMeter = explode('METER:', $trx[2])[1];
                $regToken = $this->cleanRegToken(explode('TOKEN:', $trx[3])[1]);
                $units = explode(',', $trx[5])[0];
                $cost = intval($trx[7]);
                $regId = RegMeter::where('reg_meter_number', $regMeter)->first()->id;
                $userId = MobileUser::where('user_id', auth()->user()->id)->first()->id;
                $electrixId = ElectrixMeter::where('electrix_meter_number', $electrixMeter)->first()->id;
                $electrixToken = $this->cleanEletrixToken($this->generateElectrixToken($meter, $units));
                $sale = $this->saleStore($userId, $regId, $electrixId, $cost, $cost, $regToken, $electrixToken, $units, true);
                if ($sale) {
                    return response([
                        'sale' => $sale
                    ], 200);
                }
            }
        }
    }

    public function cleanEletrixToken($token)
    {
        $remove_space = explode(" ", $token);
        $cleaned_token = implode('-', $remove_space);
        return $cleaned_token;
    }

    public function cleanRegToken($token)
    {
        $separator = "-";
        $result = preg_replace('/(\d{4})(?=\d)/', '$1' . $separator, $token);
        return $this->cleanEletrixToken($result);
    }

    public function saleStore($userId, $regId, $electrixId, $initialCost, $tokenCost, $regToken, $electrixToken, $units, $subscriptionStatus)
    {
        $sale = Sale::create([
            'mobile_user_id' => $userId,
            'reg_meter_id' => $regId,
            'electrix_meter_id' => $electrixId,
            'initial_cost' => ceil(intVal($initialCost) / 0.95),
            'token_cost' => ceil(intVal($tokenCost) / 0.95),
            'reg_meter_token' => $regToken,
            'electrix_meter_token' => $electrixToken,
            'units' => $units,
            'subscription_status' => $subscriptionStatus,
        ]);
        return $sale;
    }

    public function generateElectrixToken($meter, $units)
    {
        $amount = floatval($units) * 189;
        $meter = $this->validateElectrixMeter($meter);
        $url = getenv('ELECTRIX_ENDPOINT') . 'VendingMeter';
        if ($meter) {
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
            ])->post($url, [
                'CompanyName' => getenv('COMPANY_NAME'),
                'UserName' => getenv('USERNAME'),
                'PassWord' => getenv('PASSWORD'),
                'MeterID' => strVal($meter),
                'is_vend_by_unit' => "false",
                'Amount' => strVal($amount)
            ]);
            $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', 'electrix_electricity')->where('resolve_status', false)->orderBy('id', 'DESC')->first();
            $updateTrx = FdiTransaction::where('id', $trx->id)
                ->update([
                    'electrix_meter_number' => $meter,
                    'resolve_status' => 1,
                    'is_reg_status' => 1,
                ]);
            return $response->json()[0]['Token'];
        }
    }

    public function checkPendingStatus()
    {
        $trx_type = "electrix_electricity";
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', $trx_type)->where('resolve_status', false)->orderBy('id', 'DESC')->first();
        if (empty($trx)) {
            return response([
                'trx' => [
                    'status' => false,
                    'amount' => 0
                ]
            ], 200);
        } elseif (!empty($trx) && json_decode($trx['transaction_data'])->status_code == 0) {
            return response([
                'trx' => [
                    'status' => false,
                    'amount' => 0
                ]
            ], 200);
        } elseif (!empty($trx) && json_decode($trx['transaction_data'])->status_code == 1) {
            $trx = $trx['transaction_data'];
            $trx = explode('":"', $trx);
            $trx = explode(' ', $trx[1]);
            $cost = intval($trx[7]);
            return response([
                'trx' => [
                    'status' => true,
                    'amount' => intval($trx[7]),
                ]
            ], 200);
        }
    }

    // FDI new API

    public function balanceRequestNewAPI()
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/balance";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);

        $data = [
            'status_code' => 1,
            'status_msg' => 'Success',
            'data' => [
                'wallet_balance' => $response['total'],
                'commission' => $this->commusionBalance($response),
                'cash' => floatval($response['total']) - floatval($this->commusionBalance($response)),
            ],
            'tstamp' => now()->format('Y-m-d H:i:s')
        ];
        return $data;
    }

    public function generateFdiAuthToken()
    {
        $url = getenv('FDI_NEW_ENDPOINT') . "/auth";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            "api_key" => getenv('FDI_API_KEY'),
            "api_secret" => getenv('FDI_API_SECRET')
        ]);
        $token = $response->json()['data']['accessToken'];
        return $response = $token;
    }

    private function commusionBalance($data)
    {
        $iterationCount = 0;
        $balances = 0;
        foreach ($data['data'] as $item) {
            $iterationCount++;
            if ($iterationCount === 1) {
                continue; // Skip the first iteration
            }
            $balance = floatval($item['balance']);
            $balances += $balance;
        }
        return $balances;
    }

    public function queryMeterNewAPI($meterNo)
    {
        try {
            $token = $this->generateFdiAuthToken();
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "verticalId" => "electricity",
                "customerAccountNumber" => $meterNo
            ]);
            $data = [
                "status_code" => 1,
                "status_msg" => $response['data']['customerAccountName'],
                "data" => [
                    "vend_min_amount" => $response['data']['vendMin'],
                    "vend_max_amount" => $response['data']['vendMax'],
                    "meterno" => $meterNo,
                    "customer_name" => $response['data']['customerAccountName']
                ],
                "tstamp" => now()->format('Y-m-d H:i:s')
            ];
            return $data;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                "status_code" => 0,
                "status_msg" => "Invalid meter number",
                "data" => [
                    "meterno" => $meterNo,
                    "customer_name" => ""
                ],
                "tstamp" => now()->format('Y-m-d H:i:s')
            ];
            return $data;
        }
    }

    public function queryTrx(Request $request)
    {
        $attrs = $request->validate([
            "limit" => "required | int",
            "verticalId" => "required | string",
            "fdate" => "required | string",
            "tdate" => "required | string",
            "customerAccountNumber" => "required",
            "trxId" => "",
            "fromTime" => "",
            "toTime" => "",
        ]);
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url, [
            "limit" => $attrs['limit'],
            "verticalId" => $attrs['verticalId'],
            "fdate" => $attrs['fdate'],
            "tdate" => $attrs['tdate'],
            "customerAccountNumber" => $attrs['customerAccountNumber'],
            "trxId" => $attrs['trxId'],
            "fromTime" => $attrs['fromTime'],
            "toTime" => $attrs['toTime'],
        ]);
        return $response->json();
    }

    private function removeFirstDigits($inputString, $numDigitsToRemove)
    {
        if (is_string($inputString) && strlen($inputString) > $numDigitsToRemove) {
            $resultString = substr($inputString, $numDigitsToRemove);
            return $resultString;
        } else {
            return "Invalid input or not enough characters to remove.";
        }
    }

    public function valitateTrx($trxType, $accountNumber)
    {
        $token = $this->generateFdiAuthToken();
        try {
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/validate";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "verticalId" => $trxType,
                "customerAccountNumber" => $accountNumber
            ]);
            return $response;
        } catch (RequestException $exception) {
            $statusCode = $exception->response->status();
            $errorMessage = $exception->response->json()['msg'];
            $data = [
                'statusCode' => $statusCode,
                'errorMessage' => $errorMessage
            ];
            return $statusCode;
        }
    }

    private function executeTrx($trxId, $customerAccountNumber, $amount, $verticalId, $deliveryMethodId, $deliverTo)
    {
        $status = $this->getPreviousTrx($customerAccountNumber, $verticalId, $amount);
        if($status == true){
            $token = $this->generateFdiAuthToken();
            $url = getenv('FDI_NEW_ENDPOINT') . "/vend/execute";
            $response = Http::retry(3, 10)->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $token
            ])->post($url, [
                "trxId" => $trxId,
                "customerAccountNumber" => $customerAccountNumber,
                "amount" => $amount,
                "verticalId" => $verticalId,
                "deliveryMethodId" => $deliveryMethodId,
                "deliverTo" => $deliverTo,
                "callBack" => "https://electrix.rw/electrix-meter-api/"
            ]);
            if (intval($response->getStatusCode()) == 500) {
                return $response;
            } else {
                $response = $response->json();
                return  $response['data']['pollEndpoint'];
            }
            
        }else{
            return $response = "/v2/trx/" . $status . "/status/";
        }
    }

    public function retrieveTrx($trxId)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . $trxId;
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url);
        if ($response['data']['pdtName'] == "EUCL Prepaid Electricity") {
            if ($response['data']['spVendInfo']['voucher'] == null && $response['data']['spVendInfo']['units'] == null && $response['data']['trxStatusId'] == 'successful') {
                return $this->retrieveTrx($trxId);
            } else if ($response['data']['trxStatusId'] != 'successful') {
                $this->deleteVendTrx('electricity', $trxId);
            } else {
                return $response;
            }
        } else {
            return $response;
        }
    }

    private function storeVendTrx($trx_type, $trx_id)
    {
        $trx = VendTransaction::create([
            'mobile_user_id' => auth()->user()->mobileUser->id,
            'trx_type' => $trx_type,
            'trx_id' => $trx_id,
        ]);
        return $trx;
    }

    private function deleteVendTrx($trx_type, $trx_id)
    {
        $trx = VendTransaction::where('mobile_user_id', auth()->user()->mobileUser->id)->where('trx_type', $trx_type)->where('trx_id', $trx_id)->delete();
        return $trx;
    }

    private function retrieveVendTrx($trx_type)
    {
        $trx = VendTransaction::where('mobile_user_id', auth()->user()->mobileUser->id)->where('trx_type', $trx_type)->first();
        return $trx;
    }

    private function storeNewApiData($trx_type, $trx_id, $trx_data, $meterId)
    {
        $trx = NewApiTransaction::create([
            'mobile_user_id' => auth()->user()->mobileUser->id,
            'electrix_meter_id' => $meterId,
            'trx_type' => $trx_type,
            'trx_id' => $trx_id,
            'trx_data' => $trx_data,
        ]);
        return $trx;
    }

    public function validateTrxSuccess(Request $request)
    {
        $attrs = $request->validate([
            'meterno' => 'required | min:11',
            'amount' => 'required | numeric',
            'customer_msisdn' => 'required | min:12',
            'trxref' => 'required',
        ]);
        $trx = $this->valitateTrx('electricity', $attrs['meterno']);
        if (gettype($trx) == 'integer') {
            $data = [
                "status_code" => 0,
                "status_msg" => "Meter not found: meter number " . $attrs['meterno'] . " does not exist or is not connected.",
                "data" => [
                    "msisdn" => $attrs['customer_msisdn'],
                    "amount" => $attrs['amount']
                ]
            ];
            return response($data, 200);
        } else {
            $data = [
                "status_code" => 1,
                "status_msg" => "Meter found: " . $attrs['meterno'],
                "data" => [
                    "msisdn" => $attrs['customer_msisdn'],
                    "amount" => $attrs['amount']
                ]
            ];
            return $data;
        }
    }

    private function retrieveRegToken($meterno, $limit, $days, $verticalId)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url, [
            "limit" => $limit,
            "verticalId" => $verticalId,
            "customerAccountNumber" => $meterno,
            "fdate" => Carbon::now()->subDays($days)->format('Y-m-d'),
            "tdate" =>  now()->format('Y-m-d'),
        ]);
        return $response->json();
    }

    private function formatNumberWithHyphens($number)
    {
        $numberString = strval($number);
        if (strlen($numberString) !== 20) {
            print_r($numberString);
            throw new InvalidArgumentException("The number must have exactly 20 digits.");
        }
        $formattedNumber = chunk_split($numberString, 4, '-');
        return rtrim($formattedNumber, '-');
    }

    private function replaceSpacesWithHyphens($input)
    {
        return str_replace(' ', '-', $input);
    }

    private function extractCustomerAccountNumber($jsonString)
    {
        $data = json_decode($jsonString, true);
        if (isset($data['data']['customerAccountNumber'])) {
            return $data['data']['customerAccountNumber'];
        } else {
            return null;
        }
    }

    public function checkTrxTime($meterNo)
    {
        $meterId = ElectrixMeter::where('electrix_meter_number', $meterNo)->first()->id;
        $getTrx = NewApiTransaction::where('electrix_meter_id', $meterId)->orderBy('id', 'DESC')->first();
        if ($getTrx) {
            return $this->showTimeDifference($getTrx->created_at);
        } else {
            return 45;
        }
    }

    public function getTrxData($meterNo)
    {
        $meterId = ElectrixMeter::where('electrix_meter_number', $meterNo)->first()->id;
        $getTrx = NewApiTransaction::where('electrix_meter_id', $meterId)->orderBy('id', 'DESC')->first();
        return $getTrx->trx_id;
    }

    public function calculateTimeDifference($timestamp)
    {
        $currentTime = Carbon::now();
        $givenTime = Carbon::parse($timestamp);
        $timeDifferenceInMinutes = $currentTime->diffInMinutes($givenTime);
        return $timeDifferenceInMinutes;
    }

    public function showTimeDifference($timestamp)
    {
        $difference = $this->calculateTimeDifference($timestamp);
        return $difference;
    }

    public function checkToken()
    {
        $newAPITrx = NewApiTransaction::where('trx_type', 'electricity')->orderBy('id', 'DESC')->get();
        for ($x = 0; $x < count($newAPITrx); $x++) {
            $trx = $this->extractInfo($newAPITrx[$x]->trx_data);
            $searchToken = Sale::where('reg_meter_token', $this->formatNumberWithHyphens($trx['voucher']))->first();
            if ($searchToken) {
                continue;
            } else {
                $searchToken = TransactionReclaim::where('token', $this->formatNumberWithHyphens($trx['voucher']))->first();
                if ($searchToken) {
                    continue;
                } else {
                    $storeToken = TransactionReclaim::create([
                        'reg_meter_id' => RegMeter::where('reg_meter_number', $trx['customerAccountNumber'])->first()->id,
                        'token' => $this->formatNumberWithHyphens($trx['voucher']),
                        'units' => $trx['units'],
                        'amount' => $trx['amount'],
                        'trx_data' => $trx['data']
                    ]);
                }
            }
        }
    }

    private function extractInfo($jsonArray)
    {
        $data = json_decode($jsonArray, true);
        if ($data && isset($data['data'])) {
            $customerAccountNumber = $data['data']['customerAccountNumber'] ?? null;
            $voucher = $data['data']['spVendInfo']['voucher'] ?? null;
            $units = $data['data']['spVendInfo']['units'] ?? null;
            $amount = $data['data']['amount'] ?? null;

            return [
                'customerAccountNumber' => $customerAccountNumber,
                'voucher' => $voucher,
                'units' => $units,
                'amount' => $amount,
                'data' => $jsonArray,
            ];
        } else {
            return null;
        }
    }

    public function validateTokenUse($amount, $meterNo)
    {
        $meterId = RegMeter::where('reg_meter_number', $meterNo)->orderBy('id', 'DESC')->first();
        $trx = TransactionReclaim::where('reg_meter_id', $meterId->id)->where('amount', $amount)->where('use_status', false)->first();
        if ($trx) {
            return $trx->token;
        } else {
            return 'null';
        }
    }

    public function monthlySales($id)
    {
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $monthlySubscription = Sale::where('subscription_status', true)->where('electrix_meter_id', $meter->id)->whereYear('created_at', Carbon::now()->year)->whereMonth('created_at', Carbon::now()->month)->orderBy('id', 'DESC')->first();
        if ($monthlySubscription != "") {
            return $status = true;
        } else {
            return $status = false;
        }
    }

    public function calculateAmount($meterId, $unit){
        $status = $this->monthlySales($meterId);
        $electrixMeterId = ElectrixMeter::where('electrix_meter_number', $meterId)->first()->id;
        $regMeterId = Sale::where('electrix_meter_id', $electrixMeterId)->first()->reg_meter_id;
        $meterSpeed = RegMeter::where('id', $regMeterId)->first()->meter_speed;
        if($meterSpeed == 'slow' && $status == false){
            return $units = floatVal($unit) - 1;  
        }elseif($meterSpeed == 'faster' && $status == false){
            return $units = floatVal($unit) - 1.5; 
        } elseif ($meterSpeed == 'fast' && $status == false) {
            return $units = floatVal($unit) - 2;
        }else{
            return $unit;
        }
    }

    public function unblockTrx($regMeterId,$electrixMeterId){
        $reg_id = RegMeter::where('reg_meter_number', $regMeterId)->first()->id;
        $electrix_id = ElectrixMeter::where('electrix_meter_number', $electrixMeterId)->first()->id;
        $sale = Sale::where('reg_meter_id', $reg_id)->where('electrix_meter_id', $electrix_id)->orderBy('id', 'DESC')->first();
        if($this->showTimeDifference($sale->created_at) < 30){
            return false;
        }else{
            return true;
        }
    }

    public function getPreviousTrx($meterno, $verticalId, $amount)
    {
        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $token
        ])->get($url, [
            "limit" => 1,
            "verticalId" => $verticalId,
            "customerAccountNumber" => $meterno,
            "fdate" => Carbon::now()->subDays(1)->format('Y-m-d'),
            "tdate" =>  Carbon::now()->format('Y-m-d'),
            "fromTime" => Carbon::now()->subMinutes(6)->format('H:i'),
            "toTime" => Carbon::now()->format('H:i'),
        ]);
        $data = $response->json();
        if (count($data['data']) === 0) {
            return true;
        } else {
            $voucher = $this->formatNumberWithHyphens($data['data'][0]['voucher']);
            $voucherStatus = Sale::where('reg_meter_token', $voucher)->first();
            if($voucherStatus != NULL){
                return true;
            }else{
                if ($amount == (intval($data['data'][0]['netAmount']) * -1) && $this->showTimeDifference($data['data'][0]['createdAt']) < 60) {
                    return $data['data'][0]['trxId'];
                } else {
                    return true;
                }
            }
        }
    }

    public function trxStore(Request $request){
        $attrs = $request->validate([
            'txId' => 'required',
            'timeStamp' => 'required',
            'network' => 'required'
        ]);

        $verifyTrx = Transaction::where('txId', $attrs['txId'])->first();

        if($verifyTrx){
            return response([
                'data' => [
                    'message' => 'TrxID Alrady used', 
                    'status' => false
                    ]
            ],200);
        }else{
            $storeTrx = Transaction::create([
                'txId' => $attrs['txId'],
                'timeStamp' => $attrs['timeStamp'],
                'network' => $attrs['network'],
            ]);
            
            if($storeTrx){
                return response([
                    'data' => [
                        'message' => 'Success!',
                        'status' => true
                    ]
                ], 200);
            }
        }
     
    }

    public function trxOverride($userId, $code){
       $status = TransactionOverride::where('mobile_user_id', $userId)->where('code', $code)->first();
    if($status){
        return response([
            'data' => true
        ], 200);
    }else{
        return response([
            'data' => false
        ], 200);
    }
    }

}
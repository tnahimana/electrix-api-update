<?php

namespace App\Http\Controllers;

use App\Models\ElectrixMeter;
use App\Models\RegMeter;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class RetrieveTokenController extends Controller
{
    public function retrieveRegToken(Request $request){
        $attrs = $request->validate([
            'meterno' => 'required | min:11',
            'limit' => 'required | numeric',
            'days' => 'required | numeric | min:1'
        ]);
        
        $electrixMeter = ElectrixMeter::where('electrix_meter_number', $attrs['meterno'])->first();
        if($electrixMeter != null){
            $regMeter = RegMeter::where('id', $electrixMeter->reg_meter_id)->first()->reg_meter_number;
        }else{
            $regMeter = $attrs['meterno'];
        }

        $token = $this->generateFdiAuthToken();
        $url = getenv('FDI_NEW_ENDPOINT') . "/trx/history";
        $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization'=> 'Bearer ' . $token
        ])->get($url,[
            "limit"=> $attrs['limit'],
            "verticalId"=> 'electricity',
            "customerAccountNumber"=> $regMeter,
            "fdate"=> Carbon::now()->subDays($attrs['days'])->format('Y-m-d'),
            "tdate"=>  now()->format('Y-m-d'),
        ]);
        return $response->json(); 
    }

    public function generateFdiAuthToken(){
        $url = getenv('FDI_NEW_ENDPOINT') . "/auth";
         $response = Http::retry(3, 10)->withHeaders([
            'Accept' => 'application/json',
        ])->post($url, [
            "api_key"=> getenv('FDI_API_KEY'),
            "api_secret"=> getenv('FDI_API_SECRET')
        ]);
        $token = $response->json()['data']['accessToken'];
        return $response = $token;
    }
}
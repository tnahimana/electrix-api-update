<?php

namespace App\Http\Controllers;

use Exception;
use BulkGate\Sms\Sender;
use BulkGate\Sms\Message;
use Illuminate\Http\Request;
use BulkGate\Message\Connection;
use Illuminate\Support\Facades\Http;
use AfricasTalking\SDK\AfricasTalking;

class SmsController extends Controller
{
    public $username = 'tnahimana'; 
    // public $username = 'sandbox'; 
    // public $apiKey   = 'aac6a19271ab1e6cd03bd4e2abb0e3116249e8dfc7d6f8e1cfda2a5f87ea50fc'; //sandbox
    public $apiKey   = '7ae9f5786bfe6a007689d2c2243e83e7cc31b36012187d52b203aa7a67b05383'; //live
    public $applicationId = "32424";
    public $applicationToken = "q7RNzC4FvJcQCos9dPdk5tfijp6Yj0GawkoCHmBBSQoVr8vvKV";

    public function index(){
        return $this->bulkgate();
    }
    
    public function africatalking(){
        $AT       = new AfricasTalking($this->username, $this->apiKey);
        $sms      = $AT->sms();
        $recipients = "+250726051504";
        $message    = "Testing SMS";
        $from       = "ElectrixLtd";
        try {
        $result = $sms->send([
            'to'      => $recipients,
            'message' => $message,
            'from'    => $from
        ]);

        } catch (Exception $e) {
            return "Error: ".$e->getMessage();
        }

        return $result;
    }

    public function bulkgate(){
        $connection = new Connection($this->applicationId, $this->applicationToken);
        $sender = new Sender($connection);
        $message = new Message('250785257667', 'test message');
        $result = $sender->send($message);
        return $result;
    }

}
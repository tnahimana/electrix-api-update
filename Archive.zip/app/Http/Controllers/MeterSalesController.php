<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use App\Models\Constant;
use App\Models\RegMeter;
use App\Models\WaterSale;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Models\FdiTransaction;
use App\Models\ElectrixMeter;
use App\Models\PendingTransaction;
use App\Models\UserWallet;
use App\Models\WasacMeter;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class MeterSalesController extends Controller
{
    public $token;

    public function sales(){
        return response([
            'sales' => Sale::where('mobile_user_id', auth()->user()->mobileUser->id)
                             ->with('regmeter', 'electrixmeter')->limit(10)->orderBy('id','DESC')->get(),
        ],200);
    }

    public function sale($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->find($id);
        if($sale->subscription_status){
            $status = true;
        }else{
            $status = false;
        }
        return response([
            'sales' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('D,d-M-Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
                'subscription' => $status,
            ]
            ],200);
    }

    public function validateMeter($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();

        if($meter != ''){
            return response([
                'meter' => [
                    'reg_meter_number' => $meter->regmeter->reg_meter_number,
                    'meter_owner' => $meter->regmeter->client->firstname . " " . $meter->regmeter->client->lastname,
                    'meter_status' => $meter->meter_status,
                    'user_id' => auth()->user()->mobileUser->id,
                    'reg_meter_id' => $meter->regmeter->id,
                    'electrix_meter_id' =>$meter->id,
                    'meter_type' => $meter->regmeter->meter_type,
                ]
            ],200);
        }
        else
        {
            return response([
                'meter' => [
                    'reg_meter_number' => null,
                    'meter_owner' => null,
                    'meter_status' => null,
                    'meter_type' => null,
                ]
            ],200);
        }
    }

    private function addDashAfterFourDigits($number) {
        $numberStr = strval($number);
        $length = strlen($numberStr);
        $result = '';
        for ($i = 0; $i < $length; $i++) {
            $result .= $numberStr[$i];
            if (($i + 1) % 4 == 0 && $i != $length - 1) {
                $result .= '-';
            }
        }
        return $result;
    }

    public function saleStore(Request $request){
        $attrs = $request->validate([
            'userId' => 'required',
            'regId' => 'required',
            'electrixId' => 'required',
            'initialCost'=> 'required',
            'tokenCost' => 'required',
            'regToken' => 'required',
            'electrixToken' => 'required',
            'units' => 'required',
            'subscription_status' => 'required',
        ]);
        $tokenValidate = $this->validateTokenInsert($attrs['regToken']);
        if(!$tokenValidate){
        $sale = Sale::create([
            'mobile_user_id' => $attrs['userId'],
            'reg_meter_id' => $attrs['regId'],
            'electrix_meter_id' => $attrs['electrixId'],
            'initial_cost' => $attrs['initialCost'],
            'token_cost' => $attrs['tokenCost'],
            'reg_meter_token' => strlen($attrs['regToken']) == 20 ? $this->addDashAfterFourDigits($attrs['regToken']) : $attrs['regToken'],
            'electrix_meter_token' => $attrs['electrixToken'],
            'units' => $attrs['units'],
            'subscription_status'=> $attrs['subscription_status'],
        ]);

	if($sale){
        $meter = ElectrixMeter::where('id', $attrs['electrixId'])->first();
        $trx = FdiTransaction::where('user_id', auth()->user()->id)->where('transaction_type', 'electrix_electricity')->orderBy('id','DESC')->first();
        $updateTrx = FdiTransaction::where('id', $trx->id)
                                     ->update([
                                        'electrix_meter_number' => $meter->electrix_meter_number,
                                        'resolve_status' => 1,
                                        'is_reg_status' => 1,
                                        'override_status' => 1,
                                    ]);
        }
        }else{
            $sale = Sale::where('reg_meter_token', $attrs['regToken'])->first();
        }

        return response([
            'sale' => $sale,
        ], 200);
    }

    public function monthlySales($id){
        $meter = ElectrixMeter::where('electrix_meter_number', $id)->with('regmeter')->first();
        $last_sales = Sale::where('electrix_meter_id', $meter->id)->latest()->first();
        $sales = Sale::where('reg_meter_id', $meter->reg_meter_id)->whereMonth('created_at', Carbon::now()->month)->sum('token_cost');
        $monthlySubscription = Sale::where('subscription_status', true)->where('electrix_meter_id', $meter->id)->whereMonth('created_at', Carbon::now()->month)->orderBy('id','DESC')->first();
        if($monthlySubscription != ""){
            $status = true;
        }else{
            $status = false;
        }
        if($last_sales == null && $meter->regmeter->meter_type == 'Residential'){
            $sales = '12000';
        }else if($last_sales == null && $meter->regmeter->meter_type == 'Commercial'){
            $sales = '10000';

        }
        return response([
            'sales' => [
                'sales_amount' => $sales,
                'subscription' => $status,
            ]
        ],200);
    }

    public function saleUpdate($id){
        $sale_id = Sale::where('electrix_meter_id', $id)->orderBy('id', 'DESC')->first();
        $sale = Sale::where('id', $sale_id->id)->update([
            'commussion_status' => 'Paid',
        ]);

        return response([
            'sale' => $sale_id,
        ],200);
    }

    public function saleRedirect($id){
        $sale = Sale::with('regmeter', 'electrixmeter')->where('electrix_meter_id',$id)->orderBy('id', 'DESC')->first();

        return response([
            'sale' => [
                'id' => $sale->id,
                'initial_cost' => $sale->initial_cost,
                'created_at' => $sale->created_at->format('d.M.Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'reg_meter_token' => $sale->reg_meter_token,
                'electrix_meter_token' => $sale->electrix_meter_token,
                'reg_meter_number' => $sale->regmeter->reg_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->regmeter->client->firstname,
                'lastname' => $sale->regmeter->client->lastname,
            ]
            ],200);
    }

    public function validateTransaction($txId){
        $transaction = Transaction::where('txId', $txId)->first();
        if($transaction != ""){
            return response([
                'transaction' => [
                    'txId' => $transaction->txId,
                    'timeStamp' => $transaction->timeStamp,
                ],
            ],200);
        }else if($transaction == ""){
            return response([
                'transaction' => [
                    'txId' => "",
                    'timeStamp' => "",
                ],
            ],200);
        }
    }

    public function storeTransaction(Request $request){
        $attrs = $request->validate([
            'txId' => 'required',
            'network' => 'required',
            'timeStamp' => 'required',
        ]);

        $transaction = Transaction::create([
            'txId' => $attrs['txId'],
            'network' => $attrs['network'],
            'timeStamp' => $attrs['timeStamp'],
        ]);

        return response([
            'transaction' => $transaction,
        ], 200);

    }

    public function constants(){
        return response([
            'constants' => Constant::get()
        ], 200);
    }

    public function regValidate($id){
        $meter = RegMeter::where('reg_meter_number', $id)->first();
        if($meter != ""){
            return response([
                'meter' => [
                    'meter_number' => $meter->reg_meter_number,
                ],
            ], 200);
        }else{
            return response([
                'meter' => [
                    'meter_number' => '',
                ],
            ], 200);
        }
    }

    public function waterSale($id){
        $sale = WaterSale::with('wasacmeter', 'electrixmeter')->find($id);
        return response([
            'sales' => [
                'id' => $sale->id,
                'created_at' => $sale->created_at->format('D,d-M-Y  g:i A'),
                'token_cost' => $sale->token_cost,
                'units' => $sale->units,
                'water_meter_token' => $sale->water_meter_token,
                'wasac_meter_number' => $sale->wasacmeter->wasac_meter_number,
                'electrix_meter_number' => $sale->electrixmeter->electrix_meter_number,
                'firstname' => $sale->wasacmeter->client->firstname,
                'lastname' => $sale->wasacmeter->client->lastname,
            ]
            ],200);
    }

    public function WatersaleStore(Request $request){
        $attrs = $request->validate([
            'userId' => 'required',
            'wasacId' => 'required',
            'electrixId' => 'required',
            'tokenCost'=> 'required',
            'waterToken' => 'required',
            'units' => 'required',
        ]);
        $sale = WaterSale::create([
            'mobile_user_id' => $attrs['userId'],
            'wasac_meter_id' => $attrs['wasacId'],
            'electrix_meter_id' => $attrs['electrixId'],
            'token_cost' => $attrs['tokenCost'],
            'water_meter_token' => $attrs['waterToken'],
            'units' => $attrs['units'],
        ]);

        return response([
            'sale' => $sale,
        ], 200);
    }

    public function waterSales(){
        return response([
            'sales' => WaterSale::where('mobile_user_id', auth()->user()->mobileUser->id)
                             ->with('wasacmeter', 'electrixmeter')->limit(10)->orderBy('id','DESC')->get(),
        ],200);
    }

     public function generateWaterToken(Request $request){
        $attrs = $request->validate([
            'meterNumber'=> 'required',
            'units'=> 'required'
        ]);
        $amount = (int)$attrs['units'] * 1000;
        try {
            $response = Http::post('http://www.newapi.stronpower.com/api/VendingMeter',[
                "CompanyName" => "Genius-Solutions",
                "UserName" =>"Admin84",
                "PassWord" => "123456",
                "MeterID"=> $attrs['meterNumber'],
                "is_vend_by_unit"=> "false",
                "Amount"=> $amount
            ]);
            $result = $response->json();
            $this->token = $result[0]['Token'];
        } catch (\Throwable $th) {
            dd($th);
            return $this->token = 'Error';
        }
        return response([
            'token' => $this->token
        ],200);
    }

    public function validateWaterMeter($meter){
        $meter = ElectrixMeter::where('electrix_meter_number', $meter)->first();
        if($meter){
        $wasac_meter = WasacMeter::where('id', $meter->wasac_meter_id)->first();
        return response([
            'meter' => [
                'id' => $wasac_meter->id,
                'firstname' => $wasac_meter->client->firstname,
                'lastname' => $wasac_meter->client->lastname,
                'wasac_meter_number' => $wasac_meter->wasac_meter_number,
                'meter_status' => $wasac_meter->meter_status,
                'isWater' => true,
                'user_id' => $wasac_meter->user->mobileUser->id,
                'electrix_meter_id' => $meter->id,
                'wasac_meter_id' => $wasac_meter->id,
            ]
        ],200);
        }else{
            return response([
                'meter' => [
                    'isWater' => false,
                ]
            ],200);
        }
    }

    public function rechargeWallet(Request $request){
        $attrs = $request->validate([
            'amount' => 'required',
        ]);

        $recharge = UserWallet::create([
            'user_id' => auth()->user()->id,
            'recharge_amount' => $attrs['amount'],
            'deducted_amount' => 0,
        ]);

        return response([
            'recharge' => $recharge,
        ],200);
    }

    public function deductWallet(Request $request){
        $attrs = $request->validate([
            'amount' => 'required',
        ]);

        $recharge = UserWallet::create([
            'user_id' => auth()->user()->id,
            'recharge_amount' => 0,
            'deducted_amount' => $attrs['amount'],
        ]);

        return response([
            'recharge' => $recharge,
        ],200);
    }

    public function getWallet(){
        $recharge_amount = UserWallet::where('user_id', auth()->user()->id)->get()->sum('recharge_amount');
        $deducted_amount = UserWallet::where('user_id', auth()->user()->id)->get()->sum('deducted_amount');

        return response([
            'wallet' => [
                'balance' => intval($recharge_amount) - intVal($deducted_amount)
            ]
        ],200);
    }

    public function storePendingTransactions(Request $request){
        $attrs = $request->validate([
            'user_id' => 'required',
            'transaction_data' => 'required'
        ]);
        $trx = PendingTransaction::create([
            'user_id' => $attrs['user_id'],
            'transaction_data' => $attrs['transaction_data'],
        ]);
        return response([
            'transaction' => $trx,
        ],200);
    }

    public function getPendingTransactions($id){
        $trx = PendingTransaction::where('user_id', $id)->first();
        return response([
            'transaction' => $trx
        ],200);
    }

    public function deletePendingTransactions($id){
        $trx = PendingTransaction::where('user_id', $id)->first();
        if($trx){
           $trx->delete();
        }
        return response([
            'transaction' => json_decode($trx)
        ],200);
    }

   public function validateTokenInsert($token){
        $retrieveToken = Sale::where('reg_meter_token', $token)->first();
        if($retrieveToken){
            return true;
        }else{
            return false;
        }
    }
}
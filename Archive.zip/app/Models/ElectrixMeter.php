<?php

namespace App\Models;

use App\Models\RegMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ElectrixMeter extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function mainMeter(){
        return $this->belongsTo(RegMeter::class);
    }

    public function regmeter(){
        return $this->belongsTo(RegMeter::class,'reg_meter_id');
    }
}

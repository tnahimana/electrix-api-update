<?php

namespace App\Models;

use App\Models\MobileUser;
use App\Models\WasacMeter;
use App\Models\ElectrixMeter;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class WaterSale extends Model
{
    use HasFactory;

    protected $guarded = [];

     public function wasacmeter(){
        return $this->belongsTo(WasacMeter::class, 'wasac_meter_id');
    }

    public function electrixmeter(){
        return $this->belongsTo(ElectrixMeter::class, 'electrix_meter_id');
    }

    public function user(){
        return $this->belongsTo(MobileUser::class, 'mobile_user_id');
    }
}
<?php

use App\Models\ElectrixMeter;
use App\Models\NewApiTransaction;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('new_api_transactions', function (Blueprint $table) {
            $table->foreignIdFor(ElectrixMeter::class)->after('mobile_user_id')->nullable()->constrained()->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('new_api_transactions', function (Blueprint $table) {
            $table->dropIndex('electrix_meter_id');
            $table->dropForeign('electrix_meter_id');
            Schema::dropIfExists('electrix_meter_id');
        });
    }
};